// src/layout/MainLayout.jsx
import React from "react";
import Sidebar from "../components/Sidebar";
import HeaderBreadcrumb from "../components/HeaderBreadcrumb";

const MainLayout = ({ children, title, subtitle }) => {
  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      {/* <Sidebar /> */}
      <div style={{ flex: 1, backgroundColor: "#f5f6fa" }}>
        <HeaderBreadcrumb title={title} subtitle={subtitle} />
        <main style={{ padding: "20px" }}>{children}</main>
      </div>
    </div>
  );
};

export default MainLayout;
