import React from "react";
import "./Pets.css";

const Pets = () => {
  return (
    <div className="pets-page">
      <h2>Pets Page</h2>
    </div>
  );
};

export default Pets;
