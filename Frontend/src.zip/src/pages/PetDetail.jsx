import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import MainLayout from "../layout/MainLayout";
import PetInfoCard from "../components/PetInfoCard";
import MedicalRecordPanel from "../components/MedicalRecordPanel";
import "./PetDetail.css"; // import CSS

const PetDetail = () => {
  const { petId } = useParams();
  const [pet, setPet] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:3000/api/pets/${petId}`).then((res) => {
      setPet(res.data);
    });
  }, [petId]);

  return (
    <MainLayout title="Pet Detail" subtitle="Detailed pet medical information">
      <div className="pet-detail-container">
        {pet ? (
          <>
            <PetInfoCard pet={pet} />
            <MedicalRecordPanel petId={petId} />
          </>
        ) : (
          <p className="loading-text">Loading...</p>
        )}
      </div>
    </MainLayout>
  );
};

export default PetDetail;
