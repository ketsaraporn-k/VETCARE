import React from "react";
import MainLayout from "../layout/MainLayout";
import "./Dashboard.css"; // import CSS

const Dashboard = () => {
  return (
    <MainLayout title="Dashboard" subtitle="Welcome to VetCare Dashboard">
      <div className="dashboard-container">
        <div className="dashboard-card">
          <h3>Today's Appointments</h3>
          <p>You have 5 appointments today.</p>
        </div>

        <div className="dashboard-card">
          <h3>Active Patients</h3>
          <p>12 pets are under care.</p>
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
