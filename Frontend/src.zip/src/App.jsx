// App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Import pages
import Dashboard from "./pages/Dashboard";
import Pets from "./pages/Pets";
import PetDetail from "./pages/PetDetail";
import Profile from "./pages/Profile";

// Import Sidebar
import Sidebar from "./components/Sidebar";

function App() {
  return (
    <Router>
      <Sidebar />  {/* ตอนนี้ Sidebar จะถูกเรียกใช้ได้ */}
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/pets" element={<Pets />} />
        <Route path="/pet-detail" element={<PetDetail />} />
        <Route path="/profile" element={<Profile />} />
        {/* เพิ่ม Route อื่น ๆ ตามต้องการ */}
      </Routes>
    </Router>
  );
}

export default App;
